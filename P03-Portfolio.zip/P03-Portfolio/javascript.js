// animated menu: https://www.w3schools.com/howto/howto_css_menu_icon.asp
function myFunction(x) {
    x.classList.toggle("change");
}
